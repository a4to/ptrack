
usage: ptrack [-h] [-v] [-c] [-m]

A simple CLI utility for asthetically tracking progress when copying or moving files.

options:
  -h, --help     show this help message and exit
  -v, --verbose  verbose output
  -c, --copy     copy files (You can use `ptc` instead of `ptrack -c`)
  -m, --move     move files (You can use `ptm` instead of `ptrack -m`)

